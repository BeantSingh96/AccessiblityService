package com.knickglobal.accessibilyexample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class MacroDatabase extends SQLiteOpenHelper {
    private static int database_version = 1;
    private static String database_name = "Macro_db";
    public MacroDatabase(Context context) {
        super(context, database_name, null, database_version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(MacroData.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + MacroData.TABLE_NAME);
        onCreate(db);
    }

    public long insertData(String cordinatex, String cordinatey, String cordinatex1, String cordinatey1,
                           String cordinatex2, String cordinatey2, String cordinatex3, String cordinatey3, String cordinatex4, String cordinatey4,
                           String pname1, String pname2, String pname3, String pname4, String pname5, String time){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(MacroData.COLUMN_CORDINATEX,cordinatex);
        cv.put(MacroData.COLUMN_COARDINATEY,cordinatey);
        cv.put(MacroData.COLUMN_CORDINATEX1,cordinatex1);
        cv.put(MacroData.COLUMN_COARDINATEY1,cordinatey1);
        cv.put(MacroData.COLUMN_CORDINATEX2,cordinatex2);
        cv.put(MacroData.COLUMN_COARDINATEY2,cordinatey2);
        cv.put(MacroData.COLUMN_CORDINATEX3,cordinatex3);
        cv.put(MacroData.COLUMN_COARDINATEY3,cordinatey3);
        cv.put(MacroData.COLUMN_CORDINATEX4,cordinatex4);
        cv.put(MacroData.COLUMN_COARDINATEY4,cordinatey4);
        cv.put(MacroData.COLUMN_PACKAGENAME1,pname1);
        cv.put(MacroData.COLUMN_PACKAGENAME2,pname2);
        cv.put(MacroData.COLUMN_PACKAGENAME3,pname3);
        cv.put(MacroData.COLUMN_PACKAGENAME4,pname4);
        cv.put(MacroData.COLUMN_PACKAGENAME5,pname5);
        cv.put(MacroData.COLUMN_TIME,time);
        long id = db.insert(MacroData.TABLE_NAME,null, cv);
        db.close();
        return id;
    }
    // If you change the database schema, you must increment the database version.
    public MacroData getmode(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(MacroData.TABLE_NAME, new String[]{MacroData.COLUMN_ID,MacroData.COLUMN_CORDINATEX, MacroData.COLUMN_COARDINATEY,MacroData.COLUMN_CORDINATEX1, MacroData.COLUMN_COARDINATEY1,
                        MacroData.COLUMN_CORDINATEX2, MacroData.COLUMN_COARDINATEY2,MacroData.COLUMN_CORDINATEX3, MacroData.COLUMN_COARDINATEY3,
                        MacroData.COLUMN_CORDINATEX4, MacroData.COLUMN_COARDINATEY4,MacroData.COLUMN_PACKAGENAME1,
                        MacroData.COLUMN_PACKAGENAME2,MacroData.COLUMN_PACKAGENAME3,MacroData.COLUMN_PACKAGENAME4,
                        MacroData.COLUMN_PACKAGENAME5,MacroData.COLUMN_TIME}, MacroData.COLUMN_ID + "=?", new String[]
                        {String.valueOf(id)}
                , null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        MacroData acc = new MacroData(cursor.getInt(cursor.getColumnIndex(MacroData.COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX1)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY1)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX2)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY2)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX3)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY3)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX4)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY4)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME1)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME2)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME3)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME4)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME5)),
                cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_TIME)));
        cursor.close();
        return acc;
    }

    public List<MacroData> getlist()
    {
        List<MacroData> list=new ArrayList<>();
        String selectQuery="SELECT * FROM " + MacroData.TABLE_NAME ;
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery(selectQuery,null);
        if (cursor.moveToFirst())
        {
            do
            {
                MacroData acc=new MacroData();
                acc.setId(cursor.getInt(cursor.getColumnIndex(MacroData.COLUMN_ID)));
                acc.setCordinatex(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX)));
                acc.setCordinatey(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY)));
                acc.setCordinatex1(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX1)));
                acc.setCordinatey1(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY1)));
                acc.setCordinatex2(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX2)));
                acc.setCordinatey2(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY2)));
                acc.setCordinatex3(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX3)));
                acc.setCordinatey3(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY3)));
                acc.setCordinatex4(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_CORDINATEX4)));
                acc.setCordinatey4(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_COARDINATEY4)));
                acc.setPackagename1(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME1)));
                acc.setPackagename2(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME2)));
                acc.setPackagename3(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME3)));
                acc.setPackagename4(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME4)));
                acc.setPackagename5(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_PACKAGENAME5)));
                acc.setTime(cursor.getString(cursor.getColumnIndex(MacroData.COLUMN_TIME)));
                list.add(acc);
                Log.d("gyeosize",list.size()+"");
            }
            while (cursor.moveToNext());
        }
        db.close();
        return list;
    }
    public int getGyroCount()
    {
        String countQuary="SELECT * FROM "+ MacroData.TABLE_NAME;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery(countQuary,null);
        int count =cursor.getCount();
        cursor.close();
        return count;
    }

    public int updateGyro(MacroData gyro)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(MacroData.COLUMN_CORDINATEX,gyro.getCordinatex());
        values.put(MacroData.COLUMN_COARDINATEY,gyro.getCordinatey());
        values.put(MacroData.COLUMN_CORDINATEX1,gyro.getCordinatex1());
        values.put(MacroData.COLUMN_COARDINATEY1,gyro.getCordinatey1());
        values.put(MacroData.COLUMN_CORDINATEX2,gyro.getCordinatex2());
        values.put(MacroData.COLUMN_COARDINATEY2,gyro.getCordinatey2());
        values.put(MacroData.COLUMN_CORDINATEX3,gyro.getCordinatex3());
        values.put(MacroData.COLUMN_COARDINATEY3,gyro.getCordinatey3());
        values.put(MacroData.COLUMN_CORDINATEX4,gyro.getCordinatex4());
        values.put(MacroData.COLUMN_COARDINATEY4,gyro.getCordinatey4());
        values.put(MacroData.COLUMN_PACKAGENAME1,gyro.getPackagename1());
        values.put(MacroData.COLUMN_PACKAGENAME2,gyro.getPackagename2());
        values.put(MacroData.COLUMN_PACKAGENAME3,gyro.getPackagename3());
        values.put(MacroData.COLUMN_PACKAGENAME4,gyro.getPackagename4());
        values.put(MacroData.COLUMN_PACKAGENAME5,gyro.getPackagename5());
        values.put(MacroData.COLUMN_TIME,gyro.getTime());
        return db.update(MacroData.TABLE_NAME,values,MacroData.COLUMN_ID+"=?",new String[]
                {String.valueOf(gyro.getId())});
    }
    public void deleteGyro(MacroData gyro)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(MacroData.TABLE_NAME,MacroData.COLUMN_ID + " =? ",
                new String[] {String.valueOf(gyro.getId())});
        db.close();
    }
}
