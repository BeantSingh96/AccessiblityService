package com.knickglobal.accessibilyexample;
public class MacroData {
    public static final String TABLE_NAME = "MACRO_DB";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_CORDINATEX = "cordinatex";
    public static final String COLUMN_COARDINATEY = "cordinatey";
    public static final String COLUMN_CORDINATEX1 = "cordinatex1";
    public static final String COLUMN_COARDINATEY1 = "cordinatey1";
    public static final String COLUMN_CORDINATEX2 = "cordinatex2";
    public static final String COLUMN_COARDINATEY2 = "cordinatey2";
    public static final String COLUMN_CORDINATEX3 = "cordinatex3";
    public static final String COLUMN_COARDINATEY3 = "cordinatey3";
    public static final String COLUMN_CORDINATEX4 = "cordinatex4";
    public static final String COLUMN_COARDINATEY4 = "cordinatey4";
    public static final String COLUMN_PACKAGENAME1 = "packagename1";
    public static final String COLUMN_PACKAGENAME2 = "packagename2";
    public static final String COLUMN_PACKAGENAME3 = "packagename3";
    public static final String COLUMN_PACKAGENAME4 = "packagename4";
    public static final String COLUMN_PACKAGENAME5 = "packagename5";
    public static final String COLUMN_TIME = "time";
   private int id;
    private String cordinatex;
    private String cordinatey;
    private String cordinatex1;
    private String cordinatey1;
    private String cordinatex2;
    private String cordinatey2;
    private String cordinatex3;
    private String cordinatey3;
    private String cordinatex4;
    private String cordinatey4;
    private String packagename1;
    private String packagename2;
    private String packagename3;
    private String packagename4;
    private String packagename5;
    private String time;
    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS " + TABLE_NAME +"("
                    + COLUMN_ID +" INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_CORDINATEX +" TEXT,"
                    + COLUMN_COARDINATEY +" TEXT,"
                    + COLUMN_CORDINATEX1 +" TEXT,"
                    + COLUMN_COARDINATEY1 +" TEXT,"
                    + COLUMN_CORDINATEX2 +" TEXT,"
                    + COLUMN_COARDINATEY2 +" TEXT,"
                    + COLUMN_CORDINATEX3 +" TEXT,"
                    + COLUMN_COARDINATEY3 +" TEXT,"
                    + COLUMN_CORDINATEX4 +" TEXT,"
                    + COLUMN_COARDINATEY4 +" TEXT,"
                    + COLUMN_PACKAGENAME1 +" TEXT,"
                    + COLUMN_PACKAGENAME2 +" TEXT,"
                    + COLUMN_PACKAGENAME3 +" TEXT,"
                    + COLUMN_PACKAGENAME4 +" TEXT,"
                    + COLUMN_PACKAGENAME5 +" TEXT,"
                    + COLUMN_TIME +" TEXT"
                    + ")";
    public MacroData() {
    }

    public MacroData(int id, String cordinatex, String cordinatey, String cordinatex1, String cordinatey1, String cordinatex2, String cordinatey2, String cordinatex3, String cordinatey3, String cordinatex4, String cordinatey4, String packagename1, String packagename2, String packagename3, String packagename4, String packagename5, String time) {
        this.id = id;
        this.cordinatex = cordinatex;
        this.cordinatey = cordinatey;
        this.cordinatex1 = cordinatex1;
        this.cordinatey1 = cordinatey1;
        this.cordinatex2 = cordinatex2;
        this.cordinatey2 = cordinatey2;
        this.cordinatex3 = cordinatex3;
        this.cordinatey3 = cordinatey3;
        this.cordinatex4 = cordinatex4;
        this.cordinatey4 = cordinatey4;
        this.packagename1 = packagename1;
        this.packagename2 = packagename2;
        this.packagename3 = packagename3;
        this.packagename4 = packagename4;
        this.packagename5 = packagename5;
        this.time = time;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCordinatex() {
        return cordinatex;
    }

    public void setCordinatex(String cordinatex) {
        this.cordinatex = cordinatex;
    }

    public String getCordinatey() {
        return cordinatey;
    }

    public void setCordinatey(String cordinatey) {
        this.cordinatey = cordinatey;
    }

    public String getCordinatex1() {
        return cordinatex1;
    }

    public void setCordinatex1(String cordinatex1) {
        this.cordinatex1 = cordinatex1;
    }

    public String getCordinatey1() {
        return cordinatey1;
    }

    public void setCordinatey1(String cordinatey1) {
        this.cordinatey1 = cordinatey1;
    }

    public String getCordinatex2() {
        return cordinatex2;
    }

    public void setCordinatex2(String cordinatex2) {
        this.cordinatex2 = cordinatex2;
    }

    public String getCordinatey2() {
        return cordinatey2;
    }

    public void setCordinatey2(String cordinatey2) {
        this.cordinatey2 = cordinatey2;
    }

    public String getCordinatex3() {
        return cordinatex3;
    }

    public void setCordinatex3(String cordinatex3) {
        this.cordinatex3 = cordinatex3;
    }

    public String getCordinatey3() {
        return cordinatey3;
    }

    public void setCordinatey3(String cordinatey3) {
        this.cordinatey3 = cordinatey3;
    }

    public String getCordinatex4() {
        return cordinatex4;
    }

    public void setCordinatex4(String cordinatex4) {
        this.cordinatex4 = cordinatex4;
    }

    public String getCordinatey4() {
        return cordinatey4;
    }

    public void setCordinatey4(String cordinatey4) {
        this.cordinatey4 = cordinatey4;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPackagename1() {
        return packagename1;
    }

    public void setPackagename1(String packagename1) {
        this.packagename1 = packagename1;
    }

    public String getPackagename2() {
        return packagename2;
    }

    public void setPackagename2(String packagename2) {
        this.packagename2 = packagename2;
    }

    public String getPackagename3() {
        return packagename3;
    }

    public void setPackagename3(String packagename3) {
        this.packagename3 = packagename3;
    }

    public String getPackagename4() {
        return packagename4;
    }

    public void setPackagename4(String packagename4) {
        this.packagename4 = packagename4;
    }

    public String getPackagename5() {
        return packagename5;
    }

    public void setPackagename5(String packagename5) {
        this.packagename5 = packagename5;
    }
}
