package com.knickglobal.accessibilyexample.service

import android.accessibilityservice.GestureDescription
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ShareActionProvider
import android.widget.TextView
import androidx.annotation.IntegerRes
import androidx.annotation.RequiresApi
import com.knickglobal.accessibilyexample.*
import kotlinx.android.synthetic.main.floating_window_layout.view.*
import java.text.SimpleDateFormat
import java.util.*
import android.widget.RelativeLayout
import android.R.attr.gravity








/**
 * Created on 2018/9/28.
 * By nesto
 */
class FloatingClickService2 : Service() {
    private lateinit var manager: WindowManager
    private lateinit var view: View
    private lateinit var view1: View
    private lateinit var view2: View
    private lateinit var view3: View
    private lateinit var view4: View
    private lateinit var view5: View
    private var PRIVATE_MODE = 0
    private val PREF_NAME = "mindorks-welcome"
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var params1: WindowManager.LayoutParams
    private lateinit var params2: WindowManager.LayoutParams
    private lateinit var params3: WindowManager.LayoutParams
    private lateinit var params4: WindowManager.LayoutParams
    private lateinit var params5: WindowManager.LayoutParams
    private var xForRecord = 0
    var myInt: Int? = 1
    private var yForRecord = 0
    private val location = IntArray(2)
    private var startDragDistance: Int = 0
    private var timer: Timer? = null

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate() {
        super.onCreate()
        startDragDistance = dp2px(10f)
        view = LayoutInflater.from(this).inflate(R.layout.widget6, null)
        view1 = LayoutInflater.from(this).inflate(R.layout.widget2, null)
        view3 = LayoutInflater.from(this).inflate(R.layout.widget3, null)
        view4 = LayoutInflater.from(this).inflate(R.layout.widget4, null)
        view5 = LayoutInflater.from(this).inflate(R.layout.widget5, null)
        val sharedPref: SharedPreferences = getSharedPreferences("pos", PRIVATE_MODE)
        var position = sharedPref.getString("position", "")
        var pos = position?.let { Integer.parseInt(it) };

        view1.visibility = View.GONE;
        view3.visibility = View.GONE
        view4.visibility = View.GONE
        view5.visibility = View.GONE
        view.visibility = View.GONE

        view2 = LayoutInflater.from(this).inflate(R.layout.floating_window_layout, null)
        view2.visibility = View.GONE



        //setting the layout parameters
        val overlayParam =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    WindowManager.LayoutParams.TYPE_PHONE
                }
        params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.LEFT

        params1 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params2 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params3 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params4 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params5 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        //getting windows services and adding the floating view to it
        manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dbHandler = MacroDatabase(this)
        var xx = pos?.let { dbHandler.getlist().get(it).cordinatex }
        var yy = pos?.let { dbHandler.getlist().get(it).cordinatey }
        var xx1 = pos?.let { dbHandler.getlist().get(it).cordinatex1 }
        var yy1 = pos?.let { dbHandler.getlist().get(it).cordinatey1 }
        var xx2 = pos?.let { dbHandler.getlist().get(it).cordinatex2 }
        var yy2 = pos?.let { dbHandler.getlist().get(it).cordinatey2 }
        var xx3 = pos?.let { dbHandler.getlist().get(it).cordinatex3 }
        var yy3 = pos?.let { dbHandler.getlist().get(it).cordinatey3 }
        var xx4 = pos?.let { dbHandler.getlist().get(it).cordinatex4 }
        var yy4 = pos?.let { dbHandler.getlist().get(it).cordinatey4 }
        var d= pos?.let { dbHandler.getlist().get(it).packagename1 }
        var d1= pos?.let { dbHandler.getlist().get(it).packagename2 }
        var d2= pos?.let { dbHandler.getlist().get(it).packagename3 }
        var d3= pos?.let { dbHandler.getlist().get(it).packagename4 }
        var d4= pos?.let { dbHandler.getlist().get(it).packagename5 }
        var x = xx?.let { Integer.parseInt(it) }
        var y = yy?.let { Integer.parseInt(it) }
        var duration = d?.toLongOrNull()

        var floatX : Float? = x?.toFloat()
        var floatY : Float? = y?.toFloat()

        if (x != null) {
            params.x = x-80
        }
        if (y != null) {
            params.y = y-120
        }

        if (duration != null) {
            Handler().postDelayed({
                //doSomethingHere()
                view.visibility = View.VISIBLE
                manager.addView(view, params)
                if (x != null) {
                    if (y != null) {
                        autoClickService?.click(x, y)
                    }
                }
            }, duration)
        }
        if(!xx1.equals(""))
        {
            var x1 = xx1?.let { Integer.parseInt(it) }
            var y1 = yy1?.let { Integer.parseInt(it) }
            var duration1 = d1?.toLongOrNull()
            params1.x= x1!!
            params1.y= y1!!
            if (duration1 != null) {
                Handler().postDelayed({
                    //doSomethingHere()
                    view.visibility = View.VISIBLE
                    if (x1 != null) {
                        if (y1 != null) {
                            autoClickService?.click(x1, y1)
                        }
                    }
                }, duration1)
            }
        }
      if(!xx2.equals(""))
      {
          var x2 = xx2?.let { Integer.parseInt(it) }
          var y2 = yy2?.let { Integer.parseInt(it) }
          var duration2 = d2?.toLongOrNull()
          params3.x= x2!!
          params3.y= y2!!
          if (duration2 != null) {
              Handler().postDelayed({
                  //doSomethingHere()
                  view.visibility = View.VISIBLE
                  if (x2 != null) {
                      if (y2 != null) {
                          autoClickService?.click(x2, y2)
                      }
                  }
              }, duration2)
          }
      }
       if(!xx3.equals(""))
       {
           var x3 = xx3?.let { Integer.parseInt(it) }
           var y3 = yy3?.let { Integer.parseInt(it) }
           var duration3 = d3?.toLongOrNull()
           params4.x= x3!!
           params4.y= y3!!
           if (duration3 != null) {
               Handler().postDelayed({
                   //doSomethingHere()
                   if (x3 != null) {
                       if (y3 != null) {
                           view.visibility = View.VISIBLE
                           autoClickService?.click(x3, y3)
                       }
                   }
               }, duration3)
           }
       }
       if(!xx4.equals(""))
       {
           var x4 = xx4?.let { Integer.parseInt(it) }
           var y4 = yy4?.let { Integer.parseInt(it) }
           var duration4 = d4?.toLongOrNull()
           params5.x= x4!!
           params5.y= y4!!
           if (duration4 != null) {
               Handler().postDelayed({
                   //doSomethingHere()
                   view.visibility = View.VISIBLE
                   if (x4 != null) {
                       if (y4 != null) {
                           autoClickService?.click(x4, y4)
                       }
                   }
               }, duration4)
           }
       }
        manager.addView(view1, params1)
       // manager.addView(view2, params2)
        manager.addView(view3, params3)
        manager.addView(view4, params4)
        manager.addView(view5, params5)

        //adding an touchlistener to make drag movement of the floating widget





    }

    override fun onDestroy() {
        super.onDestroy()
        "FloatingClickService onDestroy".logd()
        manager.removeView(view)
    }

    override fun onConfigurationChanged(newConfig: Configuration?) {
        super.onConfigurationChanged(newConfig)
        "FloatingClickService onConfigurationChanged".logd()
        val x = params.x
        val y = params.y
        params.x = xForRecord
        params.y = yForRecord
        xForRecord = x
        yForRecord = y
        manager.updateViewLayout(view, params)
    }

}