package com.knickglobal.accessibilyexample;

import android.os.Bundle;
import android.os.PersistableBundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Macro extends AppCompatActivity {
     RecyclerView rv;
     ArrayList<MacroData>arrayList=new ArrayList<>();
    MacroDatabase db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_macro);
        rv=(RecyclerView)findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(this));
        db=new MacroDatabase(this);
        if(db.getGyroCount()>0)
        {
            arrayList=new ArrayList<>();
            arrayList.addAll(db.getlist());
            MacroAdapter adapter=new MacroAdapter(this,arrayList);
            rv.setAdapter(adapter);



        }
    }
}
