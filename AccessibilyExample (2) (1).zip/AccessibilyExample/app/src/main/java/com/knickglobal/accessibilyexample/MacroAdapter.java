package com.knickglobal.accessibilyexample;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.knickglobal.accessibilyexample.service.FloatingClickService2;

import java.util.ArrayList;

public class MacroAdapter extends RecyclerView.Adapter<MacroAdapter.RecHolder> {
   Context context;
   ArrayList<MacroData>arrayList;

    public MacroAdapter(Context context, ArrayList<MacroData> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public RecHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.macro_inflated,parent,false);
        return new RecHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecHolder holder, int position) {
        final  MacroData model=arrayList.get(position);
      holder.txtHours1.setText(model.getCordinatex());
      holder.txtHours2.setText(model.getCordinatex1());
      holder.txtHours3.setText(model.getCordinatex2());
      holder.txtHours4.setText(model.getCordinatex3());
      holder.txtHours5.setText(model.getCordinatex4());
      holder.txtMinute1.setText(model.getCordinatey());
      holder.txtMinute2.setText(model.getCordinatey1());
      holder.txtMinute3.setText(model.getCordinatey2());
      holder.txtMinute4.setText(model.getCordinatey3());
      holder.txtMinute5.setText(model.getCordinatey4());
      holder.txtSecond1.setText(model.getPackagename1());
      holder.txtSecond2.setText(model.getPackagename2());
      holder.txtSecond3.setText(model.getPackagename3());
      holder.txtSecond4.setText(model.getPackagename4());
      holder.txtSecond5.setText(model.getPackagename5());
      holder.play.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              SharedPreferences sharedPreferences=context.getSharedPreferences("pos",Context.MODE_PRIVATE);
              SharedPreferences.Editor editor=sharedPreferences.edit();
              editor.putString("position",holder.getAdapterPosition()+"");
              editor.commit();
              Intent intent=new Intent(context, FloatingClickService2.class);
              context.startService(intent);
          }
      });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class RecHolder extends RecyclerView.ViewHolder{
     ImageView imgCheck;
     ImageView imgCheck1;
     ImageView imgCheck2;
     ImageView imgCheck3;
     ImageView imgCheck4;
     ImageView imgCheck5;
     TextView txtHours;
     TextView txtHours1;
     TextView txtHours2;
     TextView txtHours3;
     TextView txtHours4;
     TextView txtHours5;
     TextView txtMinute1;
     TextView txtMinute2;
     TextView txtMinute3;
     TextView txtMinute4;
     TextView txtMinute5;
     TextView txtSecond;
     TextView txtSecond1;
     TextView txtSecond2;
     TextView txtSecond3;
     TextView txtSecond4;
     TextView txtSecond5;
     Button play;

        public RecHolder(@NonNull View itemView) {
            super(itemView);
            txtHours1=(TextView)itemView.findViewById(R.id.txtHours1);
            txtHours2=(TextView)itemView.findViewById(R.id.txtHours2);
            txtHours3=(TextView)itemView.findViewById(R.id.txtHours3);
            txtHours4=(TextView)itemView.findViewById(R.id.txtHours4);
            txtHours5=(TextView)itemView.findViewById(R.id.txtHours5);
            txtMinute1=(TextView)itemView.findViewById(R.id.txtMinute1);
            txtMinute2=(TextView)itemView.findViewById(R.id.txtMinute2);
            txtMinute3=(TextView)itemView.findViewById(R.id.txtMinute3);
            txtMinute4=(TextView)itemView.findViewById(R.id.txtMinute4);
            txtMinute5=(TextView)itemView.findViewById(R.id.txtMinute5);
            txtSecond1=(TextView)itemView.findViewById(R.id.txtSecond1);
            txtSecond2=(TextView)itemView.findViewById(R.id.txtSecond2);
            txtSecond3=(TextView)itemView.findViewById(R.id.txtSecond3);
            txtSecond4=(TextView)itemView.findViewById(R.id.txtSecond4);
            txtSecond5=(TextView)itemView.findViewById(R.id.txtSecond5);
            play=(Button)itemView.findViewById(R.id.play);
        }
    }
}
