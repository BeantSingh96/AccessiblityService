package com.knickglobal.accessibilyexample.service

import android.annotation.TargetApi
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.view.*
import android.widget.ShareActionProvider
import android.widget.TextView
import androidx.annotation.RequiresApi
import com.knickglobal.accessibilyexample.*
import kotlinx.android.synthetic.main.floating_window_layout.view.*
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created on 2018/9/28.
 * By nesto
 */
class FloatingClickService : Service() {
    private lateinit var manager: WindowManager
    private lateinit var view: View
    private lateinit var view1: View
    private lateinit var view2: View
    private lateinit var view3: View
    private lateinit var view4: View
    private lateinit var view5: View
    private var PRIVATE_MODE = 0
    private var serviceIntent: Intent? = null
    private val PREF_NAME = "mindorks-welcome"
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var params1: WindowManager.LayoutParams
    private lateinit var params2: WindowManager.LayoutParams
    private lateinit var params3: WindowManager.LayoutParams
    private lateinit var params4: WindowManager.LayoutParams
    private lateinit var params5: WindowManager.LayoutParams
    private var xForRecord = 0
    var myInt: Int? = 1
    private var yForRecord = 0
    private val location = IntArray(2)
    private var startDragDistance: Int = 0
    private var timer: Timer? = null

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate() {
        super.onCreate()
        startDragDistance = dp2px(10f)
        view = LayoutInflater.from(this).inflate(R.layout.widget, null)
        view1 = LayoutInflater.from(this).inflate(R.layout.widget2, null)
        view3 = LayoutInflater.from(this).inflate(R.layout.widget3, null)
        view4 = LayoutInflater.from(this).inflate(R.layout.widget4, null)
        view5 = LayoutInflater.from(this).inflate(R.layout.widget5, null)
        if (myInt == 1) {
            view1.visibility = View.GONE;
            view3.visibility = View.GONE
            view4.visibility = View.GONE
            view5.visibility = View.GONE
        } else
            view1.visibility = View.VISIBLE;
        view2 = LayoutInflater.from(this).inflate(R.layout.floating_window_layout, null)

        view2.minusButton.setOnClickListener {
            if (myInt == 1) {

            } else {
                myInt = myInt?.dec()
                if (myInt!! >= 2) {
                    view1.visibility = View.VISIBLE;
                } else
                    view1.visibility = View.GONE;
                if (myInt!! >= 3) {
                    view3.visibility = View.VISIBLE;
                } else
                    view3.visibility = View.GONE;
                if (myInt!! >= 4) {
                    view4.visibility = View.VISIBLE;
                } else
                    view4.visibility = View.GONE;
                if (myInt!! >= 5) {
                    view5.visibility = View.VISIBLE;
                } else
                    view5.visibility = View.GONE;
            }

        }
        view2.addButton.setOnClickListener {
            if (myInt == 5) {

            } else {
                myInt = myInt?.inc()
                if (myInt!! >= 2) {
                    view1.visibility = View.VISIBLE;
                    view.setOnTouchListener(null)
                }
                if (myInt!! >= 3) {
                    view3.visibility = View.VISIBLE;
                    view1.setOnTouchListener(null)
                }
                if (myInt!! >= 4) {
                    view4.visibility = View.VISIBLE;
                    view3.setOnTouchListener(null)
                }
                if (myInt!! >= 5) {
                    view5.visibility = View.VISIBLE;
                    view4.setOnTouchListener(null)
                }
            }

        }
        view2.playbutton.setOnClickListener {
            view.visibility = View.GONE
            view1.visibility = View.GONE
            view3.visibility = View.GONE
            view4.visibility = View.GONE
            view5.visibility = View.GONE

            Handler().postDelayed({
                //doSomethingHere()
                view.visibility = View.VISIBLE
                view.getLocationOnScreen(location)
                val sharedPref: SharedPreferences = getSharedPreferences("location", PRIVATE_MODE)
                val editor = sharedPref.edit()
                editor.putString("Cordinatex", (location[0] + view.right).toString())
                editor.putString("cordinatey", (location[1] + view.bottom).toString())
                editor.commit()
                autoClickService?.click(location[0] + view.right,
                        location[1] + view.bottom)
            }, 2000)
            if (myInt!! >= 2) {
                Handler().postDelayed({
                    //doSomethingHere()
                    view1.visibility = View.VISIBLE
                    view.focusable
                    view1.getLocationOnScreen(location)
                    val sharedPref: SharedPreferences = getSharedPreferences("location", PRIVATE_MODE)
                    val editor = sharedPref.edit()
                    editor.putString("Cordinatex1", (location[0] + view1.right).toString())
                    editor.putString("cordinatey1", (location[1] + view1.bottom).toString())
                    editor.commit()
                    autoClickService?.click(location[0] + view1.right,
                            location[1] + view1.bottom)
                }, 10000)
            }
            if (myInt!! >= 3) {
                Handler().postDelayed({
                    //doSomethingHere()
                    view3.visibility = View.VISIBLE
                    view3.getLocationOnScreen(location)
                    val sharedPref: SharedPreferences = getSharedPreferences("location", PRIVATE_MODE)
                    val editor = sharedPref.edit()
                    editor.putString("Cordinatex2", (location[0] + view3.right).toString())
                    editor.putString("cordinatey2", (location[1] + view3.bottom).toString())
                    editor.commit()
                    autoClickService?.click(location[0] + view3.right,
                            location[1] + view3.bottom)
                }, 20000)
            }
            if (myInt!! >= 4) {
                Handler().postDelayed({
                    //doSomethingHere()
                    view4.visibility = View.VISIBLE
                    view4.getLocationOnScreen(location)
                    val sharedPref: SharedPreferences = getSharedPreferences("location", PRIVATE_MODE)
                    val editor = sharedPref.edit()
                    editor.putString("Cordinatex3", (location[0] + view4.right).toString())
                    editor.putString("cordinatey3", (location[1] + view4.bottom).toString())
                    editor.commit()
                    autoClickService?.click(location[0] + view4.right,
                            location[1] + view4.bottom)
                }, 30000)
            }
            if (myInt == 5) {
                Handler().postDelayed({
                    //doSomethingHere()
                    view5.visibility = View.VISIBLE
                    view5.getLocationOnScreen(location)
                    val sharedPref: SharedPreferences = getSharedPreferences("location", PRIVATE_MODE)
                    val editor = sharedPref.edit()
                    editor.putString("Cordinatex4", (location[0] + view5.right).toString())
                    editor.putString("cordinatey4", (location[1] + view5.bottom).toString())
                    editor.commit()
                    autoClickService?.click(location[0] + view5.right,
                            location[1] + view5.bottom)
                }, 40000)
            }


        }
        view2.saveButton.setOnClickListener {
            val sharedPref: SharedPreferences = getSharedPreferences("location", PRIVATE_MODE)
            sharedPref.getString("Cordinatex", "")
            sharedPref.getString("cordinatey", "")
            var x = sharedPref.getString("Cordinatex", "")
            var y = sharedPref.getString("cordinatey", "")
            var x1 = sharedPref.getString("Cordinatex1", "")
            var y1 = sharedPref.getString("cordinatey1", "")
            var x2 = sharedPref.getString("Cordinatex2", "")
            var y2 = sharedPref.getString("cordinatey2", "")
            var x3 = sharedPref.getString("Cordinatex3", "")
            var y3 = sharedPref.getString("cordinatey3", "")
            var x4 = sharedPref.getString("Cordinatex4", "")
            var y4 = sharedPref.getString("cordinatey4", "")
            val editor: SharedPreferences.Editor = sharedPref.edit()
            editor.clear()
            editor.commit()

            val sdf = SimpleDateFormat("hh:mm:ss")
            val currentDate = sdf.format(Date())
            System.out.println(" C DATE is  " + currentDate)
            val dbHandler = MacroDatabase(this)
            if(!x.equals("") && !x.isNullOrEmpty())
            {
                dbHandler.insertData(x, y, x1, y1, x2, y2, x3, y3, x4, y4, "2000", "10000", "20000", "30000", "40000"
                        , currentDate)
            }


        }
        view2.cancelButton.setOnClickListener {
            view.visibility = View.GONE
            view1.visibility = View.GONE
            view3.visibility = View.GONE
            view4.visibility = View.GONE
            view5.visibility = View.GONE
            view2.visibility = View.GONE
        }
        //setting the layout parameters
        val overlayParam =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    WindowManager.LayoutParams.TYPE_PHONE
                }
        params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)

        params1 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params2 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params3 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params4 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        params5 = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayParam,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT)
        //getting windows services and adding the floating view to it
        manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        params2.gravity = Gravity.TOP or Gravity.LEFT
        params2.x = 0
        params2.y = 0
        manager.addView(view, params)
        manager.addView(view1, params1)
        manager.addView(view2, params2)
        manager.addView(view3, params3)
        manager.addView(view4, params4)
        manager.addView(view5, params5)

        //adding an touchlistener to make drag movement of the floating widget

        view.setOnTouchListener(TouchAndDragListener(params, startDragDistance,
                { },
                { manager.updateViewLayout(view, params) }))

        view1.setOnTouchListener(TouchAndDragListener(params1, startDragDistance,
                { },
                { manager.updateViewLayout(view1, params1) }))

        view3.setOnTouchListener(TouchAndDragListener(params3, startDragDistance,
                { },
                { manager.updateViewLayout(view3, params3) }))


        view4.setOnTouchListener(TouchAndDragListener(params4, startDragDistance,
                { },
                { manager.updateViewLayout(view4, params4) }))


        view5.setOnTouchListener(TouchAndDragListener(params5, startDragDistance,
                { },
                { manager.updateViewLayout(view5, params5) }))

    }

    override fun onDestroy() {
        super.onDestroy()
        "FloatingClickService onDestroy".logd()
        manager.removeView(view)
    }

    override fun onConfigurationChanged(newConfig: Configuration?) {
        super.onConfigurationChanged(newConfig)
        "FloatingClickService onConfigurationChanged".logd()
        val x = params.x
        val y = params.y
        params.x = xForRecord
        params.y = yForRecord
        xForRecord = x
        yForRecord = y
        manager.updateViewLayout(view, params)
    }

}